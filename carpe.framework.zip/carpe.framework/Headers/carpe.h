//
//  carpe.h
//  carpe
//
//  Created by Krisna Gendo on 5/21/18.
//  Copyright © 2018 Evident ID. All rights reserved.
//
#if TARGET_OS_IPHONE
#import <UIKit/UIKit.h>
#endif

#import "CaptureProcessor.h"
#import "CaptureProcessorOptions.h"


#if TARGET_OS_IPHONE

#import "CaptureProcessor+ios.h"

//! Project version number for carpe.
FOUNDATION_EXPORT double carpeVersionNumber;

//! Project version string for carpe.
FOUNDATION_EXPORT const unsigned char carpeVersionString[];

#endif
