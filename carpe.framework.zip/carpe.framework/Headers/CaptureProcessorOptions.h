//
//  CaptureProcessorOptions.h
//  carpe
//
//  Created by Krisna Gendo on 6/13/18.
//  Copyright © 2018 Evident ID. All rights reserved.
//

#ifndef CaptureProcessorOptions_h
#define CaptureProcessorOptions_h

#import <Foundation/Foundation.h>




//@interface CaptureProcessorOptions: NSObject <NSCoding>
//@property int blurrSize;
//@property NSString * canny1Select;
//@property double canny1;
//@property double canny2;
//@property double canny1otsu;
//@property int dilateSize;
//- (NSMutableDictionary *)toDict;
//- (NSString *)csvHeader;
//- (NSString *)toCsv;
//@end

#endif /* CaptureProcessorOptions_h */


