//
//  CaptureProcessor.h
//  carpe
//
//  Created by Krisna Gendo on 5/30/18.
//  Copyright © 2018 Evident ID. All rights reserved.
//

#ifndef CaptureProcessor_h
#define CaptureProcessor_h

#import <AVFoundation/AVFoundation.h>
#import <Foundation/Foundation.h>
#import <CoreGraphics/CoreGraphics.h>


@interface CaptureProcessorOptions: NSObject

@property CGRect roiRect;
@property CGRect fullFrame;
@property int blurSize;
@property NSString * canny1Select;
@property double canny1;
@property double canny2;
@property double canny1otsu;
@property int dilateSize;

+ (instancetype)forApproxPolyDpWithRoi:(CGRect)roiRect fullFrame:(CGRect)fullFrame;
+ (instancetype)forHoughLinesWithRoi:(CGRect)roiRect fullFrame:(CGRect)fullFrame;
@end


@class CaptureProcessor;

@protocol CaptureProcessorDelegate
- (void)captureProcessorDidFinish:(CaptureProcessor *)processor;
@end


@interface CaptureProcessor: NSObject

@property CaptureProcessorOptions *options;
@property int imageWidth;
@property int imageHeight;
@property id<CaptureProcessorDelegate> delegate;
@property (readonly) unsigned long contourCount;
@property (readonly) unsigned long quadrilatCount;
@property (readonly, atomic)NSArray<NSValue *> * largestCgPointQuadrilateral;

- (UIImage *)deskew:(UIImage *)uiImage
                roi:(NSArray *)quadrilateralNsValues
       scaledToSize:(CGSize)scaleSize;
- (instancetype)initWithOptions:(CaptureProcessorOptions *)options;
@end

#endif
