//
//  CaptureProcessor+ios.hpp
//  carpe
//
//  Created by Krisna Gendo on 5/31/18.
//  Copyright © 2018 Evident ID. All rights reserved.
//
#ifndef CaptureProcessor_ios_h
#define CaptureProcessor_ios_h

#import "CaptureProcessor.h"

@interface CaptureProcessor (ios)
- (void)processUiImage:(UIImage *)uiImage;
- (UIImage *)uiProcessing;
- (UIImage *)uiSource;
- (UIImage *)uiSourceWithFeature:(NSString *)feature;
@end

#endif
